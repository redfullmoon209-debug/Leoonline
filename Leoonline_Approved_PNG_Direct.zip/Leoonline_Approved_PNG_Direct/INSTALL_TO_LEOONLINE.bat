@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "DEST=%~1"
if "%DEST%"=="" (
 echo Target: the existing Leoonline Godot project folder with project.godot
 set /p "DEST=Path to Leoonline folder: "
)
if not exist "%DEST%\project.godot" (
 echo ERROR: project.godot not found at "%DEST%"
 pause
 exit /b 1
)
if not exist "%DEST%\scripts" mkdir "%DEST%\scripts"
if exist "%DEST%\scripts\inventory_ui.gd" copy /Y "%DEST%\scripts\inventory_ui.gd" "%DEST%\scripts\inventory_ui.gd.bak" >nul
if not exist "%DEST%\assets\ui\approved" mkdir "%DEST%\assets\ui\approved"
xcopy /Y /I "assets\ui\approved\*.png" "%DEST%\assets\ui\approved\" >nul
if errorlevel 1 (
 echo ERROR: PNG copy failed
 pause
 exit /b 1
)
copy /Y "scripts\inventory_ui.gd" "%DEST%\scripts\inventory_ui.gd" >nul
if errorlevel 1 (
 echo ERROR: GDScript copy failed
 pause
 exit /b 1
)
echo Files installed. This does not upload anything to GitHub.
echo Open Godot and check the scene before Git commit / push.
pause
