LEOONLINE — นำ PNG ที่อนุมัติแล้วเข้า Godot 4.4.1 โดยตรง
========================================================

ชุดนี้ใช้ไฟล์ PNG จากการออกแบบที่ลูกพี่เลือกก่อนหน้านี้ทุกไฟล์แบบไม่ครอป
ไม่ใช้การวาด PNG ใหม่ และไม่เปลี่ยนข้อมูลภาพต้นฉบับ

ติดตั้งลงโปรเจกต์ Leoonline ที่มีอยู่แล้ว (ไม่ใช่โปรเจกต์เกมใหม่)
  1. แตก ZIP
  2. คลิก INSTALL_TO_LEOONLINE.bat แล้วเลือกโฟลเดอร์โปรเจกต์ Leoonline
     (โฟลเดอร์ที่มีไฟล์ project.godot)
  3. เปิด Godot 4.4.1 แล้ว Import/Run และทดสอบ B เปิดกระเป๋า
  4. ถ้าใช้ Git ให้ Commit และ Push ไฟล์ใหม่ขึ้น GitHub

ไฟล์ที่จะถูกเพิ่ม: assets/ui/approved/*.png รวม 10 ไฟล์
ไฟล์ที่จะถูกแทน: scripts/inventory_ui.gd (สำรองไฟล์เดิมเป็น inventory_ui.gd.bak ก่อน)

การเรียง Layer ใน Godot
  00  ornate_blue_gold_inventory_panel_frame.png  / กรอบใหญ่
  10  ornate_four_tab_fantasy_navigation_bar.png / 4 เมนู
  20  luminous_blue_gold_fantasy_inventory_frame.png / กรอบซ้าย-ขวา
  30  neon_winged_fantasy_equipment_slot.png   / แถบอาวุธแฟชั่น
  40  ornate_golden_crystal_inventory_slot.png / ช่องว่างของไอเทม
  41  ornate_neon_locked_inventory_slot.png    / ช่องล็อก
  50  ornate_four_row_currency_panel.png      / เงิน 4 ประเภท
  60  ornate_blue_gold_action_bar.png        / ปุ่มด้านล่าง
  70  Godot Control / ไอคอน + ข้อความ + คลิก + Tooltip (ไม่ฝังข้อความใน PNG)

สเปกที่คงไว้
  - 200 ช่อง 4 หน้า หน้าละ 50 ช่อง
  - ชุดแฟชั่น 5 ช่อง
  - อาวุธแฟชั่นมือซ้าย-ขวา หน้ากาก ผ้าคลุม อยู่แถวเดียวกัน
  - ข้อมูลไอเทมแสดงเมื่อชี้เมาส์หรือกด ไม่เขียนตัวหนังสือในช่อง
  - ฟอนต์ไทยอาศัย assets/fonts/NotoSansThai.ttf ใน repo เดิม
  - ใช้ store.gd / main.gd เดิม ไม่แก้ระบบไอเทมและเซฟ

หมายเหตุ:
  - ZIP นี้เป็นแพ็กนำเข้าในเครื่อง ยังไม่ใช่หลักฐานว่าภาพขึ้น GitHub แล้ว
  - ต้องอัปโหลดไฟล์ PNG ไป GitHub พร้อมสคริปต์ จึงจะเห็นในเกมบนเว็บ
  - หน้าจอควรตรวจภาพจริงทุกครั้งก่อนถือว่าเสร็จ
