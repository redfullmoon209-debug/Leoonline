"""Verify that all approved PNG files are byte-for-byte intact."""
import json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'asset_manifest.json').read_text())
for name,entry in manifest.items():
    p=ROOT/'assets/ui/approved'/name
    assert p.is_file(),f'Missing PNG: {name}'
    assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256'],f'Edited PNG: {name}'
    print('PASS',name)
assert len(manifest)==10
print('PASS: all 10 original PNG files verified, no crops or redraws.')
